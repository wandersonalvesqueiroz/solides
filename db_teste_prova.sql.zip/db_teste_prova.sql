SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;


CREATE TABLE `time_stamp` (
  `id` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `in_time` time DEFAULT NULL,
  `out_lunch` time DEFAULT NULL,
  `in_lunch` time DEFAULT NULL,
  `out_time` time DEFAULT NULL,
  `date_register` date NOT NULL,
  `observation` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `users` (`id`, `name`, `username`, `password`, `email`, `status`) VALUES
(1, 'Wanderson', 'admin', '21232f297a57a5a743894a0e4a801fc3', 'wandersonmg18@gmail.com', 1),
(2, 'Manuel', 'testex', 'admin', 'teste@teste.com', 0),
(3, 'José', 'teste1', 'admin', 'teste1@teste.com', 0),
(4, 'Maria', 'teste2', 'admin', 'teste2@teste.com', 0),
(5, 'Joaquim', 'teste3', 'admin', 'teste3@teste.com', 0),
(6, 'Tiozim', 'teste4', 'admin', 'teste4@teste.com', 0),
(7, 'Thalim', 'teste5', 'admin', 'teste5@teste.com', 0),
(8, 'Manuela', 'teste6', 'admin', 'teste6@teste.com', 0);


ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);


ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
